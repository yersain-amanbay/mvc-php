<?php

namespace application\lib;

class DB {
	
	function __construct(){
		echo 'Class DB';
	}	
}

?>